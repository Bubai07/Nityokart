# NITYOKART website starter

A responsive front-end demo for a grocery e-commerce store, built with plain HTML, CSS and JavaScript.

## Run locally
1. Extract `nityokart_website.zip`.
2. Open `index.html` in a modern browser.

No build tools are required. Google Fonts are loaded from the internet; the site otherwise runs locally.

## Included
- Responsive storefront and NITYOKART branding
- Category navigation and product search
- Sorting by price/name
- Product cards with add-to-cart
- Cart drawer with quantity controls and subtotal
- Wishlist toggle
- Demo checkout form and newsletter interaction
- Location label change

## Important before launch
This is a front-end prototype, not a production-ready store. Checkout is a demo and does not process payment, create a server-side order, reserve inventory, or send email. Product names, prices, stock, delivery fees, policies and contact details are sample content. Replace the demo email and connect:
- Backend/API and database for products, customers, orders and inventory
- Authentication and account management
- A payment gateway such as Razorpay or another provider available to your business
- Delivery service/area and order status tracking
- Email/SMS notifications and newsletter provider
- Privacy policy, terms, returns and customer support information
- HTTPS, deployment, monitoring and security controls

Never store payment card details directly in this static website.
