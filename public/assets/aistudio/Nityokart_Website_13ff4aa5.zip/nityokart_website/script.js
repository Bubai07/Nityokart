const products = [
 {id:1,name:"Fresh Red Apples",category:"Fruits",unit:"Pack of 4 · approx. 500 g",price:129,old:159,emoji:"🍎",badge:"Popular",bg:"#fff0ef"},
 {id:2,name:"Bananas",category:"Fruits",unit:"6 pieces",price:49,old:59,emoji:"🍌",badge:"Fresh pick",bg:"#fff8dd"},
 {id:3,name:"Sweet Oranges",category:"Fruits",unit:"Pack of 4",price:89,old:109,emoji:"🍊",badge:"",bg:"#fff1e4"},
 {id:4,name:"Green Grapes",category:"Fruits",unit:"500 g",price:79,old:99,emoji:"🍇",badge:"",bg:"#f5efff"},
 {id:5,name:"Fresh Broccoli",category:"Vegetables",unit:"1 piece",price:65,old:79,emoji:"🥦",badge:"Fresh pick",bg:"#eaf8ed"},
 {id:6,name:"Crunchy Carrots",category:"Vegetables",unit:"500 g",price:39,old:49,emoji:"🥕",badge:"",bg:"#fff1e5"},
 {id:7,name:"Farm Tomatoes",category:"Vegetables",unit:"500 g",price:35,old:45,emoji:"🍅",badge:"Popular",bg:"#fff0ee"},
 {id:8,name:"Fresh Spinach",category:"Vegetables",unit:"1 bunch",price:25,old:30,emoji:"🥬",badge:"",bg:"#edf8e9"},
 {id:9,name:"Full Cream Milk",category:"Dairy",unit:"500 ml",price:32,old:35,emoji:"🥛",badge:"Everyday",bg:"#edf5ff"},
 {id:10,name:"Farm Fresh Eggs",category:"Dairy",unit:"6 pieces",price:54,old:62,emoji:"🥚",badge:"",bg:"#fff7e5"},
 {id:11,name:"Cheddar Cheese",category:"Dairy",unit:"200 g",price:119,old:139,emoji:"🧀",badge:"",bg:"#fff3d8"},
 {id:12,name:"Butter Cookies",category:"Snacks",unit:"200 g pack",price:65,old:79,emoji:"🍪",badge:"Popular",bg:"#fff3e5"},
 {id:13,name:"Potato Chips",category:"Snacks",unit:"Large pack",price:35,old:40,emoji:"🥔",badge:"",bg:"#fff8dc"},
 {id:14,name:"Orange Juice",category:"Beverages",unit:"1 litre",price:99,old:119,emoji:"🧃",badge:"",bg:"#fff0e2"},
 {id:15,name:"Mineral Water",category:"Beverages",unit:"1 litre",price:20,old:25,emoji:"💧",badge:"",bg:"#eaf5ff"},
 {id:16,name:"Dishwashing Liquid",category:"Household",unit:"500 ml",price:89,old:105,emoji:"🧴",badge:"",bg:"#eef8ff"}
];
let activeCategory = "All";
let cart = {};
let wishlist = new Set();
let toastTimer;
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const money = n => "₹" + n.toLocaleString("en-IN");
function showToast(message){const t=$("#toast");t.textContent=message;t.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove("show"),2200);}
function filteredProducts(){let q=$("#searchInput").value.trim().toLowerCase();let list=products.filter(p=>(activeCategory==="All"||p.category===activeCategory)&&(!q||(p.name+" "+p.category+" "+p.unit).toLowerCase().includes(q)));const sort=$("#sortSelect").value;if(sort==="low")list.sort((a,b)=>a.price-b.price);if(sort==="high")list.sort((a,b)=>b.price-a.price);if(sort==="name")list.sort((a,b)=>a.name.localeCompare(b.name));return list;}
function renderProducts(){const list=filteredProducts();$("#productsHeading").textContent=activeCategory==="All"?(($("#searchInput").value.trim())?"Search results":"Popular right now"):activeCategory;$("#productGrid").innerHTML=list.map(p=>`<article class="product-card"><div class="product-image" style="background:${p.bg}"><span class="emoji">${p.emoji}</span>${p.badge?`<span class="product-badge">${p.badge}</span>`:""}<button class="wishlist ${wishlist.has(p.id)?"active":""}" data-wish="${p.id}" aria-label="Add ${p.name} to wishlist">${wishlist.has(p.id)?"♥":"♡"}</button></div><div class="product-info"><span class="product-category">${p.category}</span><h3>${p.name}</h3><span class="product-unit">${p.unit}</span><div class="product-bottom"><div><span class="price">${money(p.price)}</span><span class="old-price">${money(p.old)}</span></div><button class="add-btn" data-add="${p.id}">${cart[p.id]?"ADD MORE +":"＋ Add"}</button></div></div></article>`).join("");$("#emptyState").classList.toggle("hidden",list.length!==0);$("#productGrid").classList.toggle("hidden",list.length===0);}
function setCategory(category){activeCategory=category;$$(".nav-category").forEach(b=>b.classList.toggle("active",b.dataset.category===category));renderProducts();}
function addToCart(id){cart[id]=(cart[id]||0)+1;renderProducts();renderCart();showToast(products.find(p=>p.id===id).name+" added to cart");}
function cartQty(){return Object.values(cart).reduce((a,b)=>a+b,0);}
function subtotal(){return products.reduce((sum,p)=>sum+p.price*(cart[p.id]||0),0);}
function renderCart(){const entries=products.filter(p=>cart[p.id]);$("#cartCount").textContent=cartQty();$("#drawerCount").textContent=`(${cartQty()})`;$("#cartEmpty").classList.toggle("hidden",entries.length>0);$("#cartSummary").classList.toggle("hidden",entries.length===0);$("#cartItems").innerHTML=entries.map(p=>`<div class="cart-line"><div class="cart-line-image">${p.emoji}</div><div><h4>${p.name}</h4><small>${money(p.price)} · ${p.unit}</small><div class="quantity"><button data-qty="${p.id}" data-delta="-1" aria-label="Decrease quantity">−</button><span>${cart[p.id]}</span><button data-qty="${p.id}" data-delta="1" aria-label="Increase quantity">+</button></div></div><span class="line-price">${money(p.price*cart[p.id])}</span></div>`).join("");$("#subtotal").textContent=money(subtotal());$("#checkoutTotal").textContent=money(subtotal());}
function openCart(){$("#cartDrawer").classList.add("open");$("#cartDrawer").setAttribute("aria-hidden","false");$("#cartBackdrop").classList.remove("hidden");document.body.style.overflow="hidden";}
function closeCart(){$("#cartDrawer").classList.remove("open");$("#cartDrawer").setAttribute("aria-hidden","true");$("#cartBackdrop").classList.add("hidden");document.body.style.overflow="";}
function goShop(){ $("#shop").scrollIntoView({behavior:"smooth"});}
$$(".nav-category").forEach(b=>b.addEventListener("click",()=>{setCategory(b.dataset.category);}));
$$(".category-tile").forEach(b=>b.addEventListener("click",()=>{setCategory(b.dataset.category);$("#products").scrollIntoView({behavior:"smooth"});}));
$("#searchInput").addEventListener("input",renderProducts);
$("#sortSelect").addEventListener("change",renderProducts);
$("#productGrid").addEventListener("click",e=>{const add=e.target.closest("[data-add]");const wish=e.target.closest("[data-wish]");if(add)addToCart(Number(add.dataset.add));if(wish){const id=Number(wish.dataset.wish);wishlist.has(id)?wishlist.delete(id):wishlist.add(id);renderProducts();showToast(wishlist.has(id)?"Added to wishlist":"Removed from wishlist");}});
$("#cartItems").addEventListener("click",e=>{const b=e.target.closest("[data-qty]");if(!b)return;const id=Number(b.dataset.qty);cart[id]=(cart[id]||0)+Number(b.dataset.delta);if(cart[id]<=0)delete cart[id];renderCart();renderProducts();});
$("#cartOpenBtn").addEventListener("click",openCart);$("#closeCartBtn").addEventListener("click",closeCart);$("#cartBackdrop").addEventListener("click",closeCart);$("#continueShoppingBtn").addEventListener("click",closeCart);
$("#shopNowBtn").addEventListener("click",()=>{goShop();$("#products").scrollIntoView({behavior:"smooth"});});
$("#viewAllBtn").addEventListener("click",()=>{setCategory("All");$("#searchInput").value="";$("#products").scrollIntoView({behavior:"smooth"});});
$("#resetFilters").addEventListener("click",()=>{$("#searchInput").value="";setCategory("All");});
$("#locationBtn").addEventListener("click",()=>{const current=$("#deliveryLocation").textContent;const place=prompt("Enter your area or PIN code:",current==="Your location"?"":current);if(place&&place.trim()){$("#deliveryLocation").textContent=place.trim();showToast("Delivery area updated");}});
$("#accountBtn").addEventListener("click",()=>showToast("Account sign-in can be connected to your backend."));
$("#checkoutBtn").addEventListener("click",()=>{closeCart();$("#checkoutDialog").showModal();$("#checkoutForm").classList.remove("hidden");$("#orderSuccess").classList.add("hidden");});
$("#closeCheckoutBtn").addEventListener("click",()=>$("#checkoutDialog").close());
$("#checkoutForm").addEventListener("submit",e=>{e.preventDefault();if(!cartQty()){showToast("Your cart is empty");return;}$("#checkoutForm").classList.add("hidden");$("#orderSuccess").classList.remove("hidden");cart={};renderCart();renderProducts();});
$("#finishOrderBtn").addEventListener("click",()=>{$("#checkoutDialog").close();$("#searchInput").value="";setCategory("All");showToast("Thanks for trying NITYOKART!");});
$("#newsletterForm").addEventListener("submit",e=>{e.preventDefault();$("#newsletterMessage").textContent="Thanks for signing up! Connect an email service to collect subscribers.";$("#newsletterEmail").value="";});
$("#year").textContent=new Date().getFullYear();
renderProducts();renderCart();
